//Special Function and REservec Pins are defined in this file
//You may add other pins for your own expansions


#define echoPin A2          // Echo Pin
#define trigPin A3          // Trigger Pin
#define buzzerPin 10        // Pin for the buzzer
